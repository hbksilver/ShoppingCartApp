//
//  Model.swift
//  ShoppingCart
//
//  Created by hassan Baraka on 5/14/21.
//

import Foundation
class Product {
    var name: String!
    var productId: NSNumber!
    var categoryId: NSNumber!
    var price: NSNumber!
    var imageName: String!
}
